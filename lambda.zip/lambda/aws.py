import boto3
import botocore.exceptions
import json
import cfnresponse
import concurrent.futures
import traceback
import time

def lambda_handler(event, context):
    account_id = "548054344313"
    print(f"Hardcoded AWS Account ID: {account_id}")
    # Your logic here

def get_ec2_iam_profile_association_id(ec2_client, instance_id):
    try:
        response = ec2_client.describe_iam_instance_profile_associations(Filters=[{'Name': 'instance-id', 'Values': [instance_id]}])
        associations = response.get('IamInstanceProfileAssociations', [])
        if not associations:
            return None

        association_id = associations[0].get('AssociationId')
        return association_id
    except botocore.exceptions.ClientError as e:
        print(f'An error occurred while retrieving the association ID: {e} for instance_id {instance_id}')
        return None

def is_Default_Host_Management_Configured(region):
    try:
        # Get the AWS account ID dynamically
        sts_client = boto3.client('sts')
        account_id = sts_client.get_caller_identity()['Account']

        # Construct the setting ID ARN
        setting_id = f'arn:aws:ssm:{region}:{account_id}:servicesetting/ssm/managed-instance/default-ec2-instance-management-role'

        # Create the SSM client
        ssm_client = boto3.client('ssm', region_name=region)

        # Retrieve the service setting
        response = ssm_client.get_service_setting(SettingId=setting_id)
        service_setting = response['ServiceSetting']

        # Check the Default Host Management Configuration SettingValue
        if service_setting.get('SettingValue', '$None') == '$None':
            return False  # Default Host Management Configuration is not configured
        else:
            print(f"Default Host Management Configuration service setting for {region} - ARN: {service_setting['ARN']}, SettingValue: {service_setting.get('SettingValue', '$None')}, Status: {service_setting['Status']}")
            return True   # Default Host Management Configuration is configured
    except botocore.exceptions.ClientError as e:
        print(f'Region: {region}. An error occurred while retrieving the Default Host Management Configuration: {e}. If error is tranisient then next schedule should resolve.')
        return True  # is_Default_Host_Management_Configured() will return True for any exception. So, process_region() will skip IAM roles assignment to all EC2 machines.

def wait_for_ec2_iam_instance_profile_disassociation(ec2_client, instance_id, max_wait_time=60, poll_interval=5):
    elapsed_time = 0
    while elapsed_time < max_wait_time:
        association_id = get_ec2_iam_profile_association_id(ec2_client, instance_id)
        if not association_id:
            print(f'IAM instance profile successfully disassociated from instance: {instance_id}')
            return True
        time.sleep(poll_interval)
        elapsed_time += poll_interval
        print(f'Waiting for disassociation... {elapsed_time}/{max_wait_time} seconds elapsed.')
    print(f'Timed out waiting for disassociation on instance: {instance_id}')
    return False

def disassociate_and_associate_ec2_iam_instance_profile(ec2_client, instance, instance_id, instance_profile_name):
    association_id = get_ec2_iam_profile_association_id(ec2_client, instance_id)
    if not association_id:
        return
    try:
        ec2_client.disassociate_iam_instance_profile(AssociationId=association_id)

        if wait_for_ec2_iam_instance_profile_disassociation(ec2_client, instance_id):
            # Associate the new IAM instance profile
            ec2_client.associate_iam_instance_profile(IamInstanceProfile={'Name': instance_profile_name}, InstanceId=instance_id)
            print(f'Associated new IAM profile {instance_profile_name} to instance {instance_id}')
        else:
            print(f'Disassociation did not complete within the expected time for instance: {instance_id}')
    except botocore.exceptions.ClientError as e:
        # Specific handling for the 'IncorrectState' error code
        if e.response['Error']['Code'] == 'IncorrectState':
            print(f'Instance {instance_id} already has an existing association that prevents reassignment. Error: {e}')
        elif e.response['Error']['Code'] == 'InvalidInstanceID.NotFound':
            print(f'Instance ID {instance_id} not found: {e}')
        elif e.response['Error']['Code'] == 'InvalidParameterValue':
            print(f'Invalid parameter for instance {instance_id}: {e}')
        else:
            print(f'Unhandled error for instance {instance_id}: {e}')

def process_region(region, instance_profile_name, ec2_ssm_iam_role_name, is_ec2_ssm_iam_role_policy_update_allowed, required_policies):
    try:
        # Skip processing, if Default Host Management Configuration is configured
        if is_Default_Host_Management_Configured(region):
            print(f'Skipping IAM roles assignment to all EC2 machines in {region} as Default Host Management Configuration is configured.')
            return

        ec2_client = boto3.client('ec2', region_name=region)
        iam_client = boto3.client('iam')

        instances = ec2_client.describe_instances()
        for reservation in instances['Reservations']:
            for instance in reservation['Instances']:
                instance_id = instance['InstanceId']
                if 'IamInstanceProfile' in instance:
                    iam_instance_profile_arn = instance['IamInstanceProfile']['Arn']
                    current_instance_profile_name = iam_instance_profile_arn.split('/')[-1]
                    current_ec2_iam_instance_profile_id = instance['IamInstanceProfile']['Id']

                    try:
                        instance_profile = iam_client.get_instance_profile(InstanceProfileName=current_instance_profile_name)
                        if instance_profile['InstanceProfile']['Roles'] and instance_profile['InstanceProfile']['InstanceProfileId']:
                            iam_instance_profile_id = instance_profile['InstanceProfile']['InstanceProfileId']
                            attached_role_name = instance_profile['InstanceProfile']['Roles'][0]['RoleName']
                            role_policies = iam_client.list_attached_role_policies(RoleName=attached_role_name)
                            attached_policies = [policy['PolicyArn'] for policy in role_policies['AttachedPolicies']]

                            if all(policy in attached_policies for policy in required_policies):
                                if (current_ec2_iam_instance_profile_id == iam_instance_profile_id):
                                    print(f'Instance: {instance_id} in {region} already has the correct permissions in role: {attached_role_name} and instance profile id: {current_ec2_iam_instance_profile_id}.')
                                else:
                                    print(f'Instance: {instance_id} in {region} has invalid instance profile id (IPid). Associating the correct IPid. Invalid ec2 IPid: {current_ec2_iam_instance_profile_id}, correct iam IPid: {iam_instance_profile_id}.')
                                    disassociate_and_associate_ec2_iam_instance_profile(ec2_client, instance, instance_id, instance_profile_name)
                            else:
                                missing_policies = [policy for policy in required_policies if policy not in attached_policies]
                                print(f'Instance: {instance_id} in {region} has the incorrect permissions in role: {attached_role_name} is_ec2_ssm_iam_role_policy_update_allowed: {is_ec2_ssm_iam_role_policy_update_allowed} missing_policies: {missing_policies}')
                                if is_ec2_ssm_iam_role_policy_update_allowed:
                                    for policy_arn in missing_policies:
                                        print(f'Attaching missing policy: {policy_arn} to role: {attached_role_name}')
                                        iam_client.attach_role_policy(RoleName=attached_role_name, PolicyArn=policy_arn)
                                else:
                                    print(f'Error: Not attaching the missing policies: {missing_policies} to role: {attached_role_name} because is_ec2_ssm_iam_role_policy_update_allowed is set to false')
                        else:
                            # No role is attached, so disassociate and associate the correct instance profile
                            print(f'Instance profile {current_instance_profile_name} has no roles attached. Reassigning the IAM role.')
                            disassociate_and_associate_ec2_iam_instance_profile(ec2_client, instance, instance_id, instance_profile_name)
                            
                    except botocore.exceptions.ClientError as e:
                        if e.response['Error']['Code'] == 'NoSuchEntity':
                            print(f'Invalid instance profile {current_instance_profile_name} for instance {instance_id}. Reassigning IAM role.')
                            disassociate_and_associate_ec2_iam_instance_profile(ec2_client, instance, instance_id, instance_profile_name)
                        else:
                            print(f'Unhandled error while processing instance {instance_id}: {e}')
                else:
                    print(f'Instance: {instance_id} in {region} has been assigned the IAM role: {ec2_ssm_iam_role_name}.')
                    ec2_client.associate_iam_instance_profile(IamInstanceProfile={'Name': instance_profile_name}, InstanceId=instance_id)
    except Exception as e:
        print(f'Exception while processing AWS region: {region} {traceback.format_exc()}')

def read_input_parameters(event, context):
    try:
        print(f'Event: ' + json.dumps(event))
        if 'StackId' in event:
            print('Invoked by AWS CloudFormation')
            instance_profile_name = event['ResourceProperties'].get('ArcForServerSSMInstanceProfileName', 'Unknown')
            ec2_ssm_iam_role_name = event['ResourceProperties'].get('ArcForServerEC2SSMRoleName', 'Unknown')
            ec2_ssm_iam_role_policy_update_allowed = event['ResourceProperties'].get('EC2SSMIAMRolePolicyUpdateAllowed', 'Unknown')
            enable_schedule = event['ResourceProperties'].get('EC2SSMIAMRoleAutoAssignmentSchedule', 'Unknown')
        else:
            print('Invoked manually')
            instance_profile_name = event.get('ArcForServerSSMInstanceProfileName', 'Unknown')
            ec2_ssm_iam_role_name = event.get('ArcForServerEC2SSMRoleName', 'Unknown')
            ec2_ssm_iam_role_policy_update_allowed = event.get('EC2SSMIAMRolePolicyUpdateAllowed', 'Unknown')
            enable_schedule = 'Enable'

        if 'Unknown' in [instance_profile_name, ec2_ssm_iam_role_name, ec2_ssm_iam_role_policy_update_allowed, enable_schedule]:
            error_message = (
                f'Missing required parameter. '
                f'ArcForServerSSMInstanceProfileName: {instance_profile_name}, '
                f'ArcForServerEC2SSMRoleName: {ec2_ssm_iam_role_name}, '
                f'EC2SSMIAMRolePolicyUpdateAllowed: {ec2_ssm_iam_role_policy_update_allowed},'
                f'enable_schedule: {enable_schedule}'
            )
            print(f'Error: {error_message}')
            if 'StackId' in event:
                cfnresponse.send(event, context, cfnresponse.FAILED, {'Error': error_message})
            raise ValueError(error_message)
        
        is_ec2_ssm_iam_role_policy_update_allowed = ec2_ssm_iam_role_policy_update_allowed.lower() == 'true'       
        print(f'ArcForServerSSMInstanceProfileName: {instance_profile_name}, ArcForServerEC2SSMRoleName: {ec2_ssm_iam_role_name}, EC2SSMIAMRolePolicyUpdateAllowed: {is_ec2_ssm_iam_role_policy_update_allowed}, enable_schedule: {enable_schedule}')

        return instance_profile_name, ec2_ssm_iam_role_name, is_ec2_ssm_iam_role_policy_update_allowed, enable_schedule
    except Exception as e:
        print(f'Exception in read_input_parameters: {str(e)} {traceback.format_exc()}')
        if 'StackId' in event:
            cfnresponse.send(event, context, cfnresponse.FAILED, {'Error': f'Failed to read input parameters: {str(e)}'})
        raise

def lambda_handler(event, context):
    instance_profile_name, ec2_ssm_iam_role_name, is_ec2_ssm_iam_role_policy_update_allowed, enable_schedule = read_input_parameters(event, context)
    try:
        required_policies = ['arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore']
        ec2_client = boto3.client('ec2')
        regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
        exceptions = []  # List to store any exceptions encountered

        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = [executor.submit(process_region, region, instance_profile_name, ec2_ssm_iam_role_name, is_ec2_ssm_iam_role_policy_update_allowed, required_policies) for region in regions]
            for future, region in zip(concurrent.futures.as_completed(futures), regions):
                try:
                    future.result()
                except Exception as e:
                    print(f'Exception encountered in region {region}: {e} {traceback.format_exc()}')
                    exceptions.append(f'Region: {region}, Exception: {str(e)}')

        # If any exceptions were encountered, mark it as partial success
        if exceptions:
            success_message = 'Partial success: exceptions occurred in some regions.'
            print(f'{success_message} Errors: {exceptions}')
            if 'StackId' in event:
                cfnresponse.send(event, context, cfnresponse.SUCCESS, {'Message': success_message, 'Errors': exceptions})
        else:
            success_message = 'Completed assigning IAM roles to all EC2 machines'
            print(success_message)
            if 'StackId' in event:
                cfnresponse.send(event, context, cfnresponse.SUCCESS, {'Message': success_message})

    except Exception as e:
        print(f'Exception: {e} {traceback.format_exc()}')        
        if 'StackId' in event:
            cfnresponse.send(event, context, cfnresponse.FAILED, {'Error': str(e)})

    # If enable_schedule is set to Disable then delete the Lambda function
    if enable_schedule == 'Disable':
        print(f'Deleting the Lambda function. enable_schedule: {enable_schedule}')
        client = boto3.client('lambda')
        client.delete_function(FunctionName=context.function_name)
        print('Successfully deleted the Lambda function')
